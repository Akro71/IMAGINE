from turtle import *
from random import *
from tkinter import *

#file = open("223.txt","w")
#file.write("IMAGINE")
#file.close()

def imaginecz():
    bgpic("logoimag.PNG")
    def kalkulacka() :

        def kal2():
            root.destroy()
            butt1()
        def kal():
            root.destroy()

            def kal3():
                master.destroy()
                butt1()
            def pokracovat():
                master.destroy()
                kalkulacka()

            master=Tk()
            wo = Label(master, text="Výsledek:")
            op = Button(master ,text="Pokračovat",command=pokracovat)
            po = Button(master ,text="Zpátky",command=kal3,bg="steelblue",fg="white")
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")
            mezera3=Label(master,text=" ")
            mezera4=Label(master,text=" ")

            f = Canvas(master,width=200, height=5)
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

            po20= numinput("Kalkulačka","První číslo: ")
            po30= textinput("Kalkulačka","Znak:(+,-,*,:)  ")
            po40= numinput("Kalkulačka","Druhé číslo: ")

            xd = po20 , ":" , po40 ,"=" , po20 // po40
            xd2 = po20 , "-" , po40 ,"=" , po20 - po40
            xd3 = po20 , "*" , po40 ,"=" , po20 * po40
            xd4 = po20 , "+" , po40 ,"=" , po20 + po40

            if po30 == "+" :
                b = Label(master, text= xd4)
                wo.pack()
                b.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == "*" :
                c = Label(master, text= xd3)
                wo.pack()
                c.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == "-" :
                d = Label(master, text= xd2)
                wo.pack()
                d.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == ":" :
                e = Label(master, text= xd)#print(po20 , ":" , po40 ,"=" , po20 // po40) #// je znaménko pro dělení v Pythonu
                wo.pack()
                e.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            else:
                ng = Label(master ,text= "Omlováme se ale něco nesedí. Zkuste zkontrolovat správnost znaku.")
                wo.pack()
                ng.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()


        root = Tk()
        a = Label(root, text="Nejdříve zadejte první číslo,\n potom znak a poté druhé číslo")
        b = Button(root, text="Ok",command=kal)
        kl = Button(root, text="Zpátky",command=kal2,bg="steelblue",fg="white")
        mezera1=Label(root,text=" ")
        mezera2=Label(root,text=" ")
        f = Canvas(root,width=200, height=80)
        m = Label(root,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        a.pack()
        mezera1.pack()
        b.pack()
        mezera2.pack()
        kl.pack()
        f.pack()
        m.pack()
    def ctverec2():
        a=numinput("ČTVEREC","Zadejte délku strany a :")
        x = a*a
        xd= a*4
        master=Tk()
        def zpet():
            master.destroy()
            g_kalkulacka()
        Label(master, text="Obsah čtverce je").grid(row=1, column=1)
        Label(master, text=x,fg="steelblue",font=("Arial",15)).grid(row=2, column=1)
        Label(master, text="cm²,dm²,m²..").grid(row=3, column=1)
        Label(master, text="Obvod čtverce je").grid(row=4, column=1)
        Label(master, text=xd,fg="steelblue",font=("Arial",15)).grid(row=5, column=1)
        Label(master, text="cm,dm,m..").grid(row=6, column=1)
        Label(master, text=" ").grid(row=7, column=1)
        Button(master,text="Zpátky",command=zpet,fg="white",bg="steelblue").grid(row=8,column=1)
        Canvas(master, height=8,width=200).grid(row=9, column=1)
        Label(master, text="©2019 iMagine ",font=("Helvetica", 6)).grid(row=10,column=1)
    def kruh2():
        a=int(numinput("ČTVEREC","Zadejte poloměr kružnice :"))
        pi=3.14159
        xd = (pi*2)*a
        x= (a*a)*(3.14159)
        master=Tk()
        def zpet():
            master.destroy()
            g_kalkulacka()
        Label(master, text="Obsah kružnice je").grid(row=1, column=1)
        Label(master, text=x,fg="steelblue",font=("Arial",15)).grid(row=2, column=1)
        Label(master, text="cm²,dm²,m²..").grid(row=3, column=1)
        Label(master, text="Obvod kružnice je").grid(row=4, column=1)
        Label(master, text=xd,fg="steelblue",font=("Arial",15)).grid(row=5, column=1)
        Label(master, text="cm,dm,m..").grid(row=6, column=1)
        Label(master, text=" ").grid(row=7, column=1)
        Button(master,text="Zpátky",command=zpet,fg="white",bg="steelblue").grid(row=8,column=1)
        Canvas(master, height=8,width=200).grid(row=9, column=1)
        Label(master, text="©2019 iMagine ",font=("Helvetica", 6)).grid(row=10,column=1)

    def obdelnik2():
        a=numinput("OBDÉLNÍK","Zadejte délku strany a :")
        b=numinput("OBDÉLNÍK","Zadejte délku strany b :")
        x = a*b
        xd= (a+b)*2
        master=Tk()
        def zpet():
            master.destroy()
            g_kalkulacka()
        Label(master, text="Obsah obdélníku je").grid(row=1, column=1)
        Label(master, text=x,fg="steelblue",font=("Arial",15)).grid(row=2, column=1)
        Label(master, text="cm²,dm²,m²..").grid(row=3, column=1)
        Label(master, text="Obvod obdélníku je").grid(row=4, column=1)
        Label(master, text=xd,fg="steelblue",font=("Arial",15)).grid(row=5, column=1)
        Label(master, text="cm,dm,m..").grid(row=6, column=1)
        Label(master, text=" ").grid(row=7, column=1)
        Button(master,text="Zpátky",command=zpet,fg="white",bg="steelblue").grid(row=8,column=1)
        Canvas(master, height=8,width=200).grid(row=9, column=1)
        Label(master, text="©2019 iMagine ",font=("Helvetica", 6)).grid(row=10,column=1)

    def trojpravouhly2():
        a=numinput("TROJÚHELNÍK","Zadejte délku strany a :")
        b=numinput("TROJÚHELNÍK","Zadejte délku strany b :")
        c=numinput("TROJÚHELNÍK","Zadejte délku strany c :")
        x = (a*b)//2
        xd= (a+b+c)
        master=Tk()
        master.title(" ")
        def zpet():
            master.destroy()
            g_kalkulacka()
        Label(master, text="Obsah trojúhelníkuu je").grid(row=1, column=1)
        Label(master, text=x,fg="steelblue",font=("Arial",15)).grid(row=2, column=1)
        Label(master, text="cm²,dm²,m²..").grid(row=3, column=1)
        Label(master, text="Obvod trojúhelníku je").grid(row=4, column=1)
        Label(master, text=xd,fg="steelblue",font=("Arial",15)).grid(row=5, column=1)
        Label(master, text="cm,dm,m..").grid(row=6, column=1)
        Label(master, text=" ").grid(row=7, column=1)
        Button(master,text="Zpátky",command=zpet,fg="white",bg="steelblue").grid(row=8,column=1)
        Canvas(master, height=8,width=200).grid(row=9, column=1)
        Label(master, text="©2019 iMagine ",font=("Helvetica", 6)).grid(row=10,column=1)

    def g_kalkulacka():
        master=Tk()
        def napoveda45():
            master.destroy()
            napoveda()
        def zpatky():
            master.destroy()
            otazka_kalkulacka()

        def ctverec():
            master.destroy()
            ctverec2()
        def obdelnik():
            master.destroy()
            obdelnik2()
        def trojpravouhly():
            master.destroy()
            trojpravouhly2()
        def kruh():
            master.destroy()
            kruh2()

        Button(master, text=" ? ",command=napoveda45,bg="steelblue",fg="white",font=("Helvetica",10)).grid(row=1, column=1)
        Button(master, text=" X ",command=zpatky,bg="firebrick",fg="white",font=("Helvetica",10)).grid(row=1, column=3)
        Label(master,text="GEOMETRIE",font=("Arial",12),fg="steelblue").grid(row=1,column=2,sticky=N)
        Label(master, text=" ").grid(row=2, column=2)
        Label(master, text="Funkce Geometrická Kalkulačka \nvám spočítá obvod a obsah\ntvarů,které si zde vyberete.\n ").grid(row=3, column=2)
        #Label(master, text=" ").grid(row=4, column=2)
        Button(master, text=" Čtverec ",command=ctverec).grid(row=5, column=2)
        Label(master, text=" ").grid(row=6, column=2)
        Button(master, text=" Obdélník ",command=obdelnik).grid(row=7, column=2)
        Label(master, text=" ").grid(row=8, column=2)
        Button(master, text=" Trojúhelník \n pravoúhlý ",command=trojpravouhly).grid(row=9, column=2)
        Label(master, text=" ").grid(row=10, column=2)
        Button(master, text=" Kružnice ",command=kruh).grid(row=11, column=2)
        Label(master, text=" ").grid(row=12, column=2)
        Label(master, text="©2019 iMagine ",font=("Helvetica", 6)).grid(row=13,column=2)

    def otazka_kalkulacka():
        def kal():
            root.destroy()
            kalkulacka()
        def kal2():
            root.destroy()
            g_kalkulacka()
        def zpet():
            root.destroy()
            butt1()

        root = Tk()
        a = Label(root, text="KALKULAČKA",fg="steelblue",font=("Arial",15))
        b = Button(root, text="Kalkulačka\nklasická",command=kal)
        c = Button(root, text="Kalkulačka\ngeometrie",command=kal2)

        kl = Button(root, text="Zpátky",command=zpet,bg="steelblue",fg="white")
        mezera1=Label(root,text=" ")
        mezera2=Label(root,text=" ")
        mezera3=Label(root,text=" ")
        f = Canvas(root,width=200, height=50)
        m = Label(root,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        a.pack()
        mezera1.pack()
        b.pack()
        mezera2.pack()
        c.pack()
        mezera3.pack()
        kl.pack()
        f.pack()
        m.pack()


    def matematika() :
        for i in range(111):
            master = Tk()

            def zpatky():
                master.destroy()
                butt1()
            def scitani():
                master.destroy()
                hra2()
            def odcitani():
                master.destroy()
                hra3_odcitani()
            def deleni():
                master.destroy()
                hra4_deleni()
            def nasobeni():
                master.destroy()
                hra5_nasobeni()

            a = Label(master, text="Vyber si, co chceš procvičit:")
            b = Button(master, text="Příklady,sčítání",command=scitani)
            c = Button(master, text="Příklady,odčítání",command=odcitani)
            d = Button(master, text="Příklady,násobení",command=nasobeni)
            e = Button(master, text="Příklady,dělení",command=deleni)


            f = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=zpatky)
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")
            mezera3=Label(master,text=" ")
            mezera4=Label(master,text=" ")
            mezera5=Label(master,text=" ")
            mezera6=Label(master,text=" ")
            ok= Canvas(master,width=250, height=18,bg ="whitesmoke")
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

            ok.pack()
            a.pack()
            mezera1.pack()
            b.pack()
            mezera2.pack()
            c.pack()
            mezera4.pack()
            d.pack()
            mezera5.pack()
            e.pack()
            mezera6.pack()
            f.pack()
            mezera3.pack()
            m.pack()

            mainloop()
    def fuc():
        rodic.destroy()
        rodic.destroy()
        print("NEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTE")
        kresleni()

    def kresleni():
        rodic = Tk()

        def zpatky():
            rodic.destroy()
            clearscreen()
            bgpic("logoimag.PNG")
            butt1()
        def napoveda():
            rodic.destroy()
            kresleninapoveda()

        def nahoru():
            forward(10)
        def dolu():
            undo()
        def stred():
            for i in range(1):
                if shape() =="arrow":
                    penup()
                    color("darkorange")
                    shape("classic")
                    fuc()
                if shape()=="classic":
                    pendown()
                    color("black")
                    shape("arrow")
                    fuc()
        def doleva():
            left(45)
        def doprava():
            right(45)

        rodic.option_add('*Font', 'Verdana 10')

        y = "▲\n|"
        x = "|\n▼" #alt30 ▲

        Label(rodic,text="Ovládání",font=("Times",15),fg="steelblue").grid(row=0, column=2)
        Button(rodic, text="Zpátky",command=zpatky,bg="firebrick",fg="white",font=("Helvetica",8)).grid(row=0, column=3,sticky=E)
        Button(rodic, text="Jak   ?",command=napoveda,bg="steelblue",fg="white",font=("Helvetica",8)).grid(row=0, column=1,sticky=W)

        Label(rodic,text="  ").grid(row=1, column=1)

        Button(rodic,command=nahoru, text=y,bg="gainsboro").grid(row=2, column=2,sticky=N)

        Label(rodic, text=u"  ").grid(row=3, column=2,sticky=N)

        Button(rodic,command=doleva, text=u" <---",bg="gainsboro").grid(row=4, column=1,sticky=W)
        Button(rodic,command=stred, text=u"  ",bg="lightgrey").grid(row=4, column=2,sticky=N)
        Button(rodic,command=doprava, text=u"---> ",bg="gainsboro").grid(row=4, column=3,sticky=E)#alt 17,16

        Label(rodic, text=u"  ").grid(row=5, column=2,sticky=N)

        Button(rodic,command=dolu, text=x,bg="gainsboro").grid(row=6, column=2,sticky=N)


    def kresleninapoveda():
        clearscreen()
        master=Tk()
        def x():
            master.destroy()
            kresleni()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "Nápověda ke Kreslení",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "Spousta z nás si ráda kreslí. Na počítači je ale ")
        b = Label(master,text = "více metod kreslení než na papíře. Můžete kreslit")
        b2 = Label(master,text = "třeba šipkami,tak jako je to tady,v IMAGINE. Ale")
        a1 = Label(master,text= "i to je nutné se naučit. Proto jsou tady pro vás ")
        c = Label(master,text = "níže sepsané tipy, rady a ovládání tlačítek.")
        a2 = Label(master,text=" ")
        d = Button(master,bg="gainsboro",text = "--->")
        e = Label(master,text = " ")
        f = Label(master,text = "Šipky slouží k pohybu na papíře. Pohybujete se tak")
        g = Label(master,text = "jak vydíte, když zmáčknete tlačítko rovně,pojedete ")
        b1 = Label(master,text="rovně, když doprava, otočíte se o 45 stupňů doprava.")
        h = Label(master,text=  "Samozřejmě brzy vyjde nová verze se spoustou vylep-")
        ch= Label(master,text = "šení a s pohodlnějším ovládáním.(např. s přetáčním)")
        lop= Label(master,text = "Šipka dolů funguje jako zpátečka. Udělá krok zpět.")
        top= Label(master,text = "Na šipku musíte klikat, ne ji jen držet !")
        i = Label(master,text = " ")
        j = Button(master,bg="gainsboro",text = "   ")
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text="Tlačítko uprostřed ovládání slouží k nastavení ")
        k = Label(master,text = "Štětec NAHORU/DOLŮ. Zda je štětec nahoře či dole,")
        l = Label(master,text = "poznáte pomocí symbolů na štětci. Pokud je štětec")
        n = Label(master,text= "nahoře, má symbol oranžové šipky s výřezem na konci.")
        krop = Label(master,text= "Pokud dole (maluje) ,tak má symbol \"spláclého\"")
        o = Label(master,text= "trojuhelníku. Standartní nastavení je dole. A proč?")
        p= Label(master,text = "Tato funkce slouží k pohybování se po ploše aniž by")
        q= Label(master,text = "jste za sebou nechávali čáru.")
        mezera3=Label(master,text=" ")
        mezera4=Label(master,text=" ")


        zpatky = Button(master,text=" Zpátky ",bg="steelblue",fg="white",command=x)
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        okno.pack()

        nadpis.pack()
        a.pack()
        b.pack()
        b2.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        ch.pack()
        lop.pack()
        top.pack()
        i.pack()
        j.pack()
        mezera1.pack()
        mezera2.pack()
        k.pack()
        l.pack()
        n.pack()
        krop.pack()
        o.pack()
        p.pack()
        q.pack()
        mezera3.pack()
        zpatky.pack()
        mezera4.pack()
        copuz.pack()


    def hra():
        t = randrange(1,1000)
        x = "Myslím si číslo od 1 do 1000. Jaké to je?"
        f = True
        while f == True:

                h = numinput("Hra",x)
                if h<t :
                    x = h , "je moc malé!"

                if h>t:
                    x = h , "je moc velké!"

                if h == t :
                    f = False
                    master = Tk()
                    def pokracovat():
                        master.destroy()
                        hracicentrum()
                    def kal3():
                        master.destroy()
                        butt1()

                    d = Message(master, text= "Správně!",width= 50)
                    op = Button(master ,text="Pokračovat",command=pokracovat)
                    po = Button(master ,text="Zpátky",command=kal3,bg="steelblue",fg="white")
                    mezera1=Label(master,text=" ")
                    mezera2=Label(master,text=" ")
                    mezera3=Label(master,text=" ")
                    mezera4=Label(master,text=" ")

                    f = Canvas(master,width=200, height=5)
                    m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

                    d.pack()
                    op.pack()
                    mezera1.pack()
                    po.pack()
                    mezera2.pack()
                    mezera3.pack()
                    mezera4.pack()
                    m.pack()
                    f.pack()

    def hra3_odcitani():
        master=Tk()
        def kd():
            master.destroy()
            hra3_odcitani()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def pododcitani():
            t=randint(1,100)
            g=randint(1,100)
            zadani = t,"-",g,"="
            h=numinput("Hra",zadani)
            if h==t-g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t-g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

        def otazkaPokracovani():
            a = Label(master, text="Správně!",font=("Helvetica", 10))
            b = Label(master, text="Špatně!",font=("Helvetica", 10))
            c = Button(master, text="Ok",command=kd)
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")

            d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
            e = Canvas(master, width=200, height=5 )

        pododcitani()

    def hra2():
        master=Tk()
        def kd():
            master.destroy()
            hra2()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def podscitani():
            t=randint(1,100)
            g=randint(1,100)
            zadani = t,"+",g,"="
            h=numinput("Hra",zadani)
            if h==t+g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t+g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        podscitani()


    def hra4_deleni():
        master=Tk()
        def kd():
            master.destroy()
            hra4_deleni()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def poddeleni():
            t=randint(1,100)
            g=randint(1,10)
            zadani = t,"÷",g,"="
            h=numinput("Hra",zadani)
            if h==t//g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t//g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        poddeleni()


    def hra5_nasobeni():
        master=Tk()
        def kd():
            master.destroy()
            hra5_nasobeni()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def podnasobeni():
            t=randint(1,10)
            g=randint(1,10)
            zadani = t,"·",g,"="
            h=numinput("Hra",zadani)
            if h==t*g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t*g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        podnasobeni()

    def napoveda():
        master = Tk()
        def x():
            master.destroy()
            butt1()
        okno = Canvas(master,width=350, height=5,bg="gold")
        nadpis = Label(master,text = "Nápověda",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "----------------------------------------------------------------------------")
        #a1 = Label(master,text= "----------------------------------------------------------------------------")
        #c = Label(master,anchor=W,text = "Co dělají jednotlivé kategorie?                                             ")
        #a2 = Label(master,text= "----------------------------------------------------------------------------")
        d = Label(master,anchor=W,text = "Kalkulačka                                                                  ")
        #e = Label(master,anchor=W,text = "Vypočítá vám zadaný příklad.                                                ")
        f = Label(master,anchor=W,text = "- Používá znaménka: ( +,-,*,÷ )                                              ")
        #g = Label(master,anchor=W,text = "> + pro sčítání_____________________________________________________________")
        #b1 = Label(master,anchor=W,text= "> - pro odčítání____________________________________________________________")
        #h = Label(master,anchor=W,text=  "> : pro dělení, zaokrouhluje pokud je výsledek v desetinných číslech, zvládá")
        #b2 = Label(master,anchor=W,text= "pouze celá čísla____________________________________________________________")
        #ch= Label(master,anchor=W,text = "> * pro násobení, zvládá pouze celá čísla                                   ")
        #i = Label(master,anchor=W,text = "Zadávání čísel:                                                             ")
        j = Label(master,anchor=W,text = "-Nejdříve napište pouze první číslo. Po každém řádku stiskněte Enter.       ")
        c1= Label(master,anchor=W,text = "-Následně (po stisknutí Enter) napište znak. Znaky jsou vypsány nad polem.  ")
        k = Label(master,anchor=W,text=  "-Napíšete druhé číslo. Potom stiskněte Enter a už vám vyjede výsledek :)    ")
        c2= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        l = Label(master,anchor=W,text = "Matematika                                                                  ")
        m = Label(master,text = "Funkce Matematika s vámi cvičí příklady na sčítání,odčítání,násobení    ")
        n = Label(master,anchor=W,text = "a dělení. Zvládá pouze celá čísla a zaokrouhluje. Je možné že vám vyjde")
        o = Label(master,text = "(s pravidly Funkce)neřešitelný příklad př(16÷3). Příklad pouze odklikněte a ")
        p = Label(master,anchor=W,text = "vyjede vám nový. Za případné komplikace se omlouváme.                       ")
        q = Label(master,text = "----------------------------------------------------------------------------")
        r = Label(master,anchor=W,text = "Hry                                                                         ")
        s = Label(master,text = "Funkce zatím obsahuje dvě hry. Druhá je vysvětlena výše(Matematika)        ")
        t = Label(master,text = "První je hra na hádání čísel. Čísla jsou vybírána pomocí funkce randint v   ")
        d1= Label(master,anchor=W,text = "modulu Random. Tedy náhodně. Vaším úkolem je číslo uhádnout na co    ")
        ok= Label(master,text = "nejmenší počet pokusů. Když číslo uhádnete, IMAGINE vám to napíše. Hra  ")
        d2= Label(master,anchor=W,text = "tím končí a vy se dostanete zpátky do menu.                                 ")
        d3= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        d4= Label(master,anchor=W,fg="steelblue",text = "O IMAGINE                                                                   ")
        d5= Label(master,anchor=W,text = "IMAGINE hodně čerpá z knihovny tkinter,většina grafických částí je vytvořena")
        d6= Label(master,anchor=W,text = "právě pomocí tkinteru. Prakticky všechna okna,texty a tlačítka. Dále IMAGINE")
        d7= Label(master,anchor=W,text = "používá modulu Random, tedy Náhody. Je použita ve hrách (na vygenerování")
        d8= Label(master,anchor=W,text = "hádaného čísla) a v Matematice(na generování náhodných čísel do příkladů)")
        d9= Label(master,anchor=W,text = "Jelikož Python nepoužívá příkaz go to(), je v kódu použito definvání(z 919")
        e1= Label(master,anchor=W,text = "jich pouze 7 není v žádné funkci). Tudíž je kód méně přehledný než jiné.Ale")
        e2= Label(master,anchor=W,text = "je to výtečný nápad-jenom kvůli tomu je IMAGINE schopná fungovat.           ")
        #e3= Label(master,anchor=W,text = "pouze přeskakuje z jedné funkce do jiné(což právě způsobuje nepřehlednost).")
        e4= Label(master,anchor=W,text = " ")
        e5= Label(master,anchor=W,text = "IMAGINE vznikla na nápad Pavla Koppa,a spousta nápadů (včetně Hry 1) pochází")
        #e6= Label(master,anchor=W,text = "Spousta nápadů(včetně Hry 1)")
        e7= Label(master,anchor=W,text = " od Programovacího Kroužku MakeItToday a od Instruktora Vítka. Těmto lidem ")
        e8= Label(master,anchor=W,text = "patří dík. Naprogramoval Tomáš Andrus.")
        e9= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        #e0= Label(master,anchor=W,text = " ")
        f1= Button(master,text="Zpátky",command=x,bg="steelblue",fg="white")

        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        nadpis.pack()

        a.pack()
        #a1.pack()
        #c.pack()
        #a2.pack()
        d.pack()
        #e.pack()
        f.pack()
        #g.pack()
        #b1.pack()
        #h.pack()
        #b2.pack()
        #ch.pack()
        #i.pack()
        j.pack()
        c1.pack()
        k.pack()
        c2.pack()
        l.pack()
        m.pack()
        n.pack()
        o.pack()
        p.pack()
        q.pack()
        r.pack()
        s.pack()
        t.pack()
        d1.pack()
        ok.pack()
        d2.pack()
        d3.pack()
        d4.pack()
        d5.pack()
        d6.pack()
        d7.pack()
        d8.pack()
        d9.pack()
        e1.pack()
        e2.pack()
        #e3.pack()
        e4.pack()
        e5.pack()
        #e6.pack()
        e7.pack()
        e8.pack()
        e9.pack()
        #e0.pack()
        f1.pack()


        copuz.pack()

        okno.pack()


    def hracicentrum():
        master=Tk()

        def a1():
            master.destroy()
            hra()
        def b1():
            master.destroy()
            clearscreen()
            pu()
            setpos(-100,0)  #pozice
            pd()
            hra2()
        def c1():
            master.destroy()
            butt1()

        a =Label(master,text="Jakou hru si chcete zahrát? ")
        b = Button(master, text="Hádání čísla",command= a1)
        c = Button(master, text="Sčítání,příklady",command=b1)
        x = Button(master, text="Zpátky",command=c1, bg="steelblue",fg="white")#dodgerblue/lehce svetlejsi
        d = Canvas(master, width=200, height=20)
        e_mezera = Label(master,text=" ")
        b_mezera = Label(master,text=" ")
        c_mezera = Label(master,text=" ")
        m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a.pack()

        b_mezera.pack()

        b.pack()

        e_mezera.pack()

        c.pack()

        c_mezera.pack()

        x.pack()
        d.pack()
        m.pack()
    def upgrade():
        master=Tk()
        def x():
            master.destroy()
            coming()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "A co s tím co už tady je?",fg="gold",font=("Helvetica",15))
        a = Label(master,text = "Nebojte,stále na tom pracujeme a vytváříme")
        b = Label(master,text = "nové verze již vydaných programů.")
        b2 = Label(master,text = "Na co se můžete těšit ?")
        a1 = Label(master,text=" ")
        c = Button(master,text = "Hry")
        a2 = Label(master,text=" ")
        d = Label(master,text = "Možná jste si všimli že naše hry zatím")
        e = Label(master,text = "nejsou nic extra. Je jich málo a jsou")
        f = Label(master,text = "víc matematické nežli zábavné.To vyřeší")
        g = Label(master,text = "následující verze IMAGINE! Bude větší ")
        b1 = Label(master,text="výběr her a budou lépe graficky zpracované.")
        h = Label(master,text=  "Přibyde také funkce na zmněnu jazyka. ")
        ch= Label(master,text = "K dispozici bude Angličtina a Čeština.")
        i = Label(master,text = "Na novou verzi IMAGINE(Hry, a Jazyky) se")
        j = Label(master,text = "můžete tešit 19.11.!Určitě se vám bude líbit.")
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        zpatky = Button(master,text=" Zpátky ",bg="steelblue",fg="white",command=x)
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        okno.pack()

        nadpis.pack()
        a.pack()
        b.pack()
        b2.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        ch.pack()
        i.pack()
        j.pack()
        mezera1.pack()
        zpatky.pack()
        mezera2.pack()
        copuz.pack()

    def coming():
        master = Tk()
        def x():
            master.destroy()
            butt1()
        def up():
            master.destroy()
            upgrade()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "Přijde vám to málo?",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "Nám taky. A snažíme se na tom pracovat.")
        b = Label(master,text = "Již brzy vyjdou následující funkce:  ")
        a1 = Label(master,text=" ")
        c = Button(master,text = "Jazyky")
        a2 = Label(master,text=" ")
        d = Label(master,text = "Až doposud byla celá IMAGINE pouze v ")
        e = Label(master,text = "češtině. To se zmnění v následující")
        f = Label(master,text = "aktualizaci(19.11.). Celá IMAGINE bude")
        g = Label(master,text = "dostupná v angličtině. Vyjde 19-25.11.")
        b1 = Label(master,text=" ")
        h = Button(master,text = "Angličtina")
        b2 = Label(master,text=" ")
        ch= Label(master,text = "Funkce Angličtina vás naučí základy   ")
        i = Label(master,text = "Anglického Jazyka. Čísla,barvy,       ")
        j = Label(master,text = "zvířata atd. Funkce vyjde 3.12.       ")
        c1= Label(master,text = " ")
        k = Button(master,text="Chat")
        c2= Label(master,text = " ")
        l = Label(master,text = "Povídáte si rádi? A že nemáte s kým?  ")
        m = Label(master,text = "Nevadí! Od toho tu je iMagine,uživatesky")
        n = Label(master,text = "přívětivý program využívající strojového")
        o = Label(master,text = "učení TensorFlow.iMagine je milá,pozorná")
        p = Label(master,text = "a počítačově chytrá asistentka.       ")
        q = Label(master,text = "Svěřit se jí můžete opravdu se vším.  ")
        r = Label(master,text = "Říkat by to nikomu nemněla ☺. Datum   ")
        s = Label(master,text = "vydání je zatím bohužel neznámé. Očkává")
        t = Label(master,text = "se kolem lednu - únoru roku 2020.")
        d1= Label(master,text = " ")
        ok= Button(master,text= " Zpátky ",command=x,fg="white",bg ="steelblue")
        apk= Button(master,text= "Aktualizace",command=up,fg="white",bg ="gold")
        apk1m= Label(master,text = " ")

        #d2= Label(master,text = " ")
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        nadpis.pack()

        a.pack()
        b.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        b2.pack()
        ch.pack()
        i.pack()
        j.pack()
        c1.pack()
        k.pack()
        c2.pack()
        l.pack()
        m.pack()
        n.pack()
        o.pack()
        p.pack()
        q.pack()
        r.pack()
        s.pack()
        t.pack()
        apk1m.pack()
        apk.pack()
        d1.pack()
        ok.pack()
        #d2.pack()
        copuz.pack()

        okno.pack()

    def otazkaBack(x):
        master = Tk()
        def b1():
            master.destroy()
            if x == hracicentrum:
                hracicentrum()
            if x == kalkulacka:
                kalkulacka()
            if x == matematika:
                matematika()
        def c1():
            master.destroy()
            butt1()
        a =Label(master,text="Chcete pokračovat? ")
        b = Button(master, text="Pokračovat",command= b1)
        c = Button(master, text="Zpátky",command=c1, bg="steelblue",fg="white")#dodgerblue/lehce svetlejsi
        d = Canvas(master, width=200, height=80)
        e_mezera = Label(master,text=" ")
        b_mezera = Label(master,text=" ")
        m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a.pack()

        b_mezera.pack()

        b.pack()

        e_mezera.pack()

        c.pack()
        d.pack()
        m.pack()

    def zmenahesla():
        master=Tk()
        def zpatkyy():
            master.destroy()
            nastaveni4()
        def nove():
            master.destroy()
            okno=Tk()
            def noveheslo22():
                okno.destroy()
                def uuu():
                    okino.destroy()
                    butt1()
                noveheslo=textinput("NOVÉ HESLO","Zadejte nové heslo:")
                file = open("223heslo.txt","w")
                file.write(noveheslo)
                file.close()
                okino=Tk()
                a=Label(okino,text="Heslo bylo úspěšně\nzměněno !")
                a.pack()
                b=Button(okino,text="Ok",fg="white",bg="steelblue",command=uuu)
                b.pack()
            nadpis=Label(okno,text="ZMĚNA HESLA",fg="steelblue",font=("Arial",15))
            nadpis.pack()
            a=Label(okno,text="Zadáte nové heslo a kliknete\n na Ok. Heslo je pouze\n na vás ale doporučujeme\n vybrat silné heslo \n alespoň o 5 znacích.")
            a.pack()
            b=Button(okno,text="Souhlasím",fg="white",bg="steelblue",command=noveheslo22)
            b.pack()
        a=Label(master,text="ZMĚNA HESLA",fg="steelblue",font=("Arial",15))
        a.pack()
        b=Label(master,text=" ")
        b.pack()
        c=Label(master,text="Opravdu chcete změnit své heslo?")
        c.pack()
        d=Button(master,text="Ano",bg="firebrick",fg="white",command=nove)
        d.pack(side=LEFT,anchor=E,expand=True)
        d=Button(master,text="Ne",bg="steelblue",fg="white",command=zpatkyy)
        d.pack(side=RIGHT,anchor=W,expand=True)

    def zmenajmena():
        master=Tk()
        def zpatkyy():
            master.destroy()
            nastaveni4()
        def nove():
            master.destroy()
            okno=Tk()
            def novejmeno22():
                okno.destroy()
                def uuu():
                    okino.destroy()
                    butt1()
                novejmeno=textinput("NOVÉ UŽIVATELSKÉ JMÉNO","Zadejte nové Už. jméno:")
                file = open("uzivatelskejmeno.txt","w")
                file.write(novejmeno)
                file.close()
                okino=Tk()
                a=Label(okino,text="Jméno bylo úspěšně\nzměněno !")
                a.pack()
                b=Button(okino,text="Ok",fg="white",bg="steelblue",command=uuu)
                b.pack()
            nadpis=Label(okno,text="ZMĚNA JMÉNA",fg="steelblue",font=("Arial",15))
            nadpis.pack()
            a=Label(okno,text="Zadáte nové Jméno a kliknete\n na Ok. Jméno je pouze\n na vás ale doporučujeme\n vybrat zapamatovatelné \n jméno alespoň o 5 znacích.")
            a.pack()
            b=Button(okno,text="Souhlasím",fg="white",bg="steelblue",command=novejmeno22)
            b.pack()
        a=Label(master,text="ZMĚNA UŽ. JMÉNA",fg="steelblue",font=("Arial",15))
        a.pack()
        b=Label(master,text=" ")
        b.pack()
        c=Label(master,text="Opravdu chcete změnit své \nUživatelské Jméno?")
        c.pack()
        d=Button(master,text="Ano",bg="firebrick",fg="white",command=nove)
        d.pack(side=LEFT,anchor=E,expand=True)
        d=Button(master,text="Ne",bg="steelblue",fg="white",command=zpatkyy)
        d.pack(side=RIGHT,anchor=W,expand=True)

    def koupitimagine():
        master=Tk()
        master.title(" ")
        master.config(bg="steelblue")
        a=Label(master,text="Placená verze ještě\nnení k dispozici.\nPlánované vydání :\n3.12. 2019",bg="gold")
        a.pack()

    def nastaveni4():

        master=Tk()
        def aj():
            master.destroy()
            imagineaj()
        def zpatky():
            master.destroy()
            butt1()
        def napoveda45():
            master.destroy()
            napoveda()
        def hesloz():
            master.destroy()
            okno=Tk()
            def heslohgh():
                okno.destroy()
                zmenahesla()
            def uzjmeno1():
                okno.destroy()
                zmenajmena()
            a=Label(okno,text="RESETOVÁNÍ",fg="steelblue",font=("Arial",15))
            a.pack(side=TOP)
            b=Label(okno,text=" ")
            b.pack(side=TOP)
            c=Button(okno,text="Resetování\nHesla",command=heslohgh,fg="white",bg="steelblue")
            c.pack(side=RIGHT,anchor=E,expand=True)
            c=Button(okno,text="Resetování\nUž. jména",command=uzjmeno1,fg="white",bg="steelblue")
            c.pack(side=LEFT,anchor=W,expand=True)

        def koupe2():
            koupitimagine()
        def vypnuto():
            okno=Tk()
            def koupe():
                okno.destroy()
                koupitimagine()
            def zpatky44():
                okno.destroy()

            a=Label(okno,text="Upozornění si můžete vypnout\npouze v placené verzi.\nChcete si ji koupit?")
            a.pack()
            d=Button(okno,text="Ano",bg="gold",fg="white",command=koupe)
            d.pack(side=LEFT,anchor=E,expand=True)
            d=Button(okno,text="Ne",bg="steelblue",fg="white",command=zpatky44)
            d.pack(side=RIGHT,anchor=W,expand=True)

        Label(master,text=" Nastavení",font=("Arial",11),fg="steelblue").grid(row=1,column=2,sticky=E)
        Button(master, text=" ? ",command=napoveda45,bg="steelblue",fg="white",font=("Helvetica",10)).grid(row=1, column=1)
        Button(master, text=" X ",command=zpatky,bg="firebrick",fg="white",font=("Helvetica",10)).grid(row=1, column=4)
        Label(master,text="IMAGINE ",font=("Arial",12),fg="steelblue").grid(row=1,column=3,sticky=W)

        Label(master,text=" ").grid(row=2,column=2)

        Button(master, text="Čeština",command=napoveda,font=("Helvetica",9),relief=SUNKEN,state=DISABLED).grid(row=3, column=2,sticky=E)
        Button(master, text="Angličtina",command=aj,font=("Helvetica",9)).grid(row=3, column=3,sticky=W)

        #Button(master, text="Barva",command=napoveda,font=("Helvetica",12)).grid(row=4, column=2,sticky=E)
        #Button(master, text="   X   ",command=napoveda,font=("Helvetica",12)).grid(row=4, column=3,sticky=W)

        Label(master,text="Upozornění").grid(row=4, column=2,sticky=E)
        Label(master,text=":").grid(row=4,column=3,sticky=W)

        Button(master, text="Zap.",command=napoveda,relief=SUNKEN,state=DISABLED,font=("Helvetica",9)).grid(row=5, column=2,sticky=E)
        Button(master, text="Vyp.",command=vypnuto,font=("Helvetica",9)).grid(row=5, column=3,sticky=W)
        #Button(master, text="   6   ",command=napoveda,font=("Helvetica",12)).grid(row=6, column=2)
        #Button(master, text="   7   ",command=napoveda,font=("Helvetica",12)).grid(row=6, column=3)

        Label(master,text="  ").grid(row=6, column=2)

        Button(master, text="Resetovat\nIMAGINE",fg="white",bg="steelblue",command=hesloz,font=("Helvetica",10)).grid(row=7, column=2)
        Button(master, text="Koupit",command=koupe2,fg="white",bg="gold",font=("Helvetica",10)).grid(row=7, column=3)
        #Button(master, text="   9   ",command=napoveda,font=("Helvetica",12)).grid(row=8, column=2)
        #Button(master, text="   10   ",command=napoveda,font=("Helvetica",12)).grid(row=8, column=3)
        #Canvas(master,height=100,width=5).grid(row=8, column=2)


    def butt1():
        master = Tk()
        master.title(" ")
        #master.config(bg="gold")
        def aj744():
            master.destroy()
            imagineaj()
        def a1():
            master.destroy()
            otazka_kalkulacka()

        def a2():
            master.destroy()
            matematika()

        def a3():
            master.destroy()
            hracicentrum()

        def a4():
            master.destroy()
            napoveda()
        def a5():
            master.destroy()
            clearscreen()
            shape("arrow")
            kresleni()
        def pripravujeme():
            master.destroy()
            coming()
        def nastaveni1():
            master.destroy()
            nastaveni4()

        #x = Message(master,text= "Vyber:12" ,width=50) #snese pouye 8 znaku
        nadpis = Label(master,text="IMAGINE",font=("Helvetica", 30),fg="steelblue")
        h = Label(master, text=" „Think Different” ",font=("Helvetica", 8),fg="steelblue")
        ch= Label(master, text="Vyber si z těchto kategorií která tě zajímá. ")

        q = Label(master, text=" ")
        i = Label(master, text=" ")
        j = Label(master, text=" ")
        k = Label(master, text=" ")
        q = Label(master, text=" ")
        w = Label(master, text=" ")


        a = Button(master,padx=7, text= "Kalkulačka",command=a1)
        b = Button(master,padx=4, text= "Matematika",command=a2)
        c = Button(master,padx=26, text= "Hry",command=a3)
        f = Button(master,padx=15, text= "Kreslení",command=a5)
        chystase = Button(master, text= "Připravujeme",command=pripravujeme,bg="gold",fg="white")
        a1 = Label(master,text=" ")
        mezera1 = Label(master,text=" ")
        d = Button(master,padx=9, text= "Nápověda",command=a4,bg="steelblue",fg="white")
        e = Canvas(master, width=400, height=20)

        nadpis.pack()
        h.pack()
        ch.pack()
        q.pack()

        a.pack()
        i.pack()

        b.pack()
        j.pack()

        c.pack()
        k.pack()
        f.pack()
        mezera1.pack()
        chystase.pack()
        a1.pack()

        d.pack()
        e.pack()
        l = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        l.pack(side=TOP)
        m = Button(master, text= "Nastavení",font=("Arial",8),bg="steelblue",fg="white",command=nastaveni1)
        m.pack(side=LEFT)
        #q.pack()
        #w.pack()
        m = Label(master,text=" ")
        m.pack(side=LEFT)
        m = Label(master,text=" ")
        m.pack(side=LEFT)


        m = Button(master, text= "Čeština",state=DISABLED,relief=SUNKEN)
        m.pack(side=RIGHT)
        m = Button(master, text= "Angličtina",command=aj744)
        m.pack(side=RIGHT)


    def butt_uvodni():
        master = Tk()
        master.title(" ")
        def aj744():
            master.destroy()
            imagineaj()
        def a1():
            master.destroy()
            otazka_kalkulacka()

        def a2():
            master.destroy()
            matematika()

        def a3():
            master.destroy()
            hracicentrum()

        def a4():
            master.destroy()
            napoveda()
        def a5():
            master.destroy()
            clearscreen()
            shape("arrow")
            kresleni()
        def pripravujeme():
            master.destroy()
            coming()
        def nastaveni1():
            master.destroy()
            nastaveni4()
        nadpis = Label(master,text="IMAGINE",font=("Helvetica", 30),fg="steelblue")
        mezera1 = Label(master, text=" „Think Different” ",font=("Helvetica", 8),fg="steelblue")

        x = Label(master, text="Ahoj! Jmenuji se IMAGINE.",fg= "black",font=("Helvetica", 10))    #fg/ barva pisma
        #x = Message(master,text= "Vyber:12" ,width=50) #snese pouye 8 znaku
        f1 = Label(master, text="Jsem jednoduchý program na vzdělávání ")
        g = Label(master, text="a zábavu. Jo a ještě... Nečekejte Jarvise ;)")
        h = Label(master, text=" ")
        ch= Label(master, text="Vyber si z těchto kategorií která tě zajímá. ")

        i = Label(master, text=" ")
        j = Label(master, text=" ")
        k = Label(master, text=" ")
        q = Label(master, text=" ")
        #w = Label(master, text=" ")

        #m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a = Button(master,padx=7, text= "Kalkulačka",command=a1)
        b = Button(master,padx=4, text= "Matematika",command=a2)
        c = Button(master,padx=26, text= "Hry",command=a3)
        d = Button(master,padx=9, text= "Nápověda",command=a4,bg="steelblue",fg="white")
        f = Button(master,padx=15, text= "Kreslení",command=a5)

        chystase = Button(master, text= "Připravujeme",command=pripravujeme,bg="gold",fg="white")

        e = Canvas(master, width=400, height=5)

        chystaseX = Label(master,text="Chystá se :")
        chystase_1 = Button(master,text="Kreslení")
        chystase_2 = Button(master,text="Angličtina")
        chystase_3 = Button(master,text="Chat")
        a1= Label(master,text="")
        a2= Label(master,text="")
        a3= Label(master,text="")
        a4= Label(master,text="")
        ok1= Label(master,text="")
        ok2= Label(master,text="")


        nadpis.pack()
        mezera1.pack()
        x.pack()
        f1.pack()
        g.pack()
        h.pack()
        ch.pack()

        a.pack()
        i.pack()

        b.pack()
        j.pack()

        c.pack()
        k.pack()
        f.pack()
        ok1.pack()
        chystase.pack()
        a1.pack()
        #chystaseX.pack()
        #a1.pack()
        #chystase_1.pack()
        #chystase_1.config(state="disabled",relief="sunken")
        #a2.pack()
        #chystase_2.pack()
        #chystase_2.config(state="disabled",relief="sunken")
        #a3.pack()
        #chystase_3.pack()
        #chystase_3.config(state="disabled",relief="sunken")
        #a4.pack()
        d.pack()
        e.pack()

        q.pack()
        #w.pack()
        l = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        l.pack(side=TOP)
        m = Button(master, text= "Nastavení",font=("Arial",8),bg="steelblue",fg="white",command=nastaveni1)
        m.pack(side=LEFT)
        #q.pack()
        #w.pack()
        m = Label(master,text=" ")
        m.pack(side=LEFT)
        m = Label(master,text=" ")
        m.pack(side=LEFT)


        m = Button(master, text= "Čeština",state=DISABLED,relief=SUNKEN)
        m.pack(side=RIGHT)
        m = Button(master, text= "Angličtina",command=aj744)
        m.pack(side=RIGHT)

    def imagine() :
        print("<<<Kalkulačka/Matematika/Hry/Nápověda>>>") #povídání,kreslení,angličtina,
        print("_________________________________________________")
        print("|  | |  |      |   |       |      |   |   |      |")
        print("|  | |  |   ___|   |       |   |  |   |   |   ___|")
        print("|  | |  |      |   |    |__|   |  |  \_/  |      |")
        print("|  ___  |   ___|   |__  |  |   |  |   |   |   ___| ")
        print("|   |   |      |      |    |      |   |   |      |")
        print("\___|___|______|______|____|______|___|___|______/ " )
        butt_uvodni()

    def heslo():
        l = textinput("IMAGINE","Name")
        if l == "tom_22" :
            b = textinput(l , "Passworld")
            if b == "IMAGINE" :
                print("Ahoj, jmenuji se Imagine. Jsem jednoduchý program na vzdělávání a zábavu.")
                print("Pokaždé když budete chtít nazpátek,napište Back.")
                print("(Jen si dávej pozor na správnost :) )")
                imagine()
            else :
                print("Wrong Passworld")
        else :
            print("1Wrong Name!")
            heslo()

    imagine()

    exitonclick()
    mainloop()






def imagineaj():
    bgpic("logoimag.PNG")
    def kalkulacka() :

        def kal2():
            root.destroy()
            butt1()
        def kal():
            root.destroy()

            def kal3():
                master.destroy()
                butt1()
            def pokracovat():
                master.destroy()
                kalkulacka()

            master=Tk()
            wo = Label(master, text="Výsledek:")
            op = Button(master ,text="Pokračovat",command=pokracovat)
            po = Button(master ,text="Zpátky",command=kal3,bg="steelblue",fg="white")
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")
            mezera3=Label(master,text=" ")
            mezera4=Label(master,text=" ")

            f = Canvas(master,width=200, height=5)
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

            po20= numinput("Kalkulačka","Číslo: ")
            po30= textinput("Kalkulačka","Znak:(+,-,*,:)  ")
            po40= numinput("Kalkulačka","Číslo: ")

            xd = po20 , ":" , po40 ,"=" , po20 // po40
            xd2 = po20 , "-" , po40 ,"=" , po20 - po40
            xd3 = po20 , "*" , po40 ,"=" , po20 * po40
            xd4 = po20 , "+" , po40 ,"=" , po20 + po40

            if po30 == "+" :
                b = Label(master, text= xd4)
                wo.pack()
                b.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == "*" :
                c = Label(master, text= xd3)
                wo.pack()
                c.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == "-" :
                d = Label(master, text= xd2)
                wo.pack()
                d.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            elif po30 == ":" :
                e = Label(master, text= xd)#print(po20 , ":" , po40 ,"=" , po20 // po40) #// je znaménko pro dělení v Pythonu
                wo.pack()
                e.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()
            else:
                ng = Label(master ,text= "Omlováme se ale něco nesedí. Zkuste zkontrolovat správnost znaku.")
                wo.pack()
                ng.pack()
                op.pack()
                mezera1.pack()
                po.pack()
                mezera2.pack()
                mezera3.pack()
                mezera4.pack()
                m.pack()
                f.pack()


        root = Tk()
        a = Label(root, text="Nejdříve zadejte první číslo,\n potom znak a poté druhé číslo")
        b = Button(root, text="Ok",command=kal)
        kl = Button(root, text="Zpátky",command=kal2,bg="steelblue",fg="white")
        mezera1=Label(root,text=" ")
        mezera2=Label(root,text=" ")
        f = Canvas(root,width=200, height=80)
        m = Label(root,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        a.pack()
        mezera1.pack()
        b.pack()
        mezera2.pack()
        kl.pack()
        f.pack()
        m.pack()


    def matematika() :
        master = Tk()
        for i in range(111):
            master = Tk()

            def zpatky():
                master.destroy()
                butt1()
            def scitani():
                master.destroy()
                hra2()
            def odcitani():
                master.destroy()
                hra3_odcitani()
            def deleni():
                master.destroy()
                hra4_deleni()
            def nasobeni():
                master.destroy()
                hra5_nasobeni()

            a = Label(master, text="Vyber si, co chceš procvičit:")
            b = Button(master, text="Příklady,sčítání",command=scitani)
            c = Button(master, text="Příklady,odčítání",command=odcitani)
            d = Button(master, text="Příklady,násobení",command=nasobeni)
            e = Button(master, text="Příklady,dělení",command=deleni)


            f = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=zpatky)
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")
            mezera3=Label(master,text=" ")
            mezera4=Label(master,text=" ")
            mezera5=Label(master,text=" ")
            mezera6=Label(master,text=" ")
            ok= Canvas(master,width=250, height=18,bg ="whitesmoke")
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

            ok.pack()
            a.pack()
            mezera1.pack()
            b.pack()
            mezera2.pack()
            c.pack()
            mezera4.pack()
            d.pack()
            mezera5.pack()
            e.pack()
            mezera6.pack()
            f.pack()
            mezera3.pack()
            m.pack()

            mainloop()
    def fuc():
        rodic.destroy()
        rodic.destroy()
        print("NEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTENEREAGUJTE")
        kresleni()

    def kresleni():
        rodic = Tk()

        def zpatky():
            rodic.destroy()
            clearscreen()
            butt1()
        def napoveda():
            rodic.destroy()
            kresleninapoveda()

        def nahoru():
            forward(10)
        def dolu():
            undo()
        def stred():
            for i in range(1):
                if shape() =="arrow":
                    penup()
                    color("darkorange")
                    shape("classic")
                    fuc()
                if shape()=="classic":
                    pendown()
                    color("black")
                    shape("arrow")
                    fuc()
        def doleva():
            left(45)
        def doprava():
            right(45)

        rodic.option_add('*Font', 'Verdana 10')

        y = "▲\n|"
        x = "|\n▼" #alt30 ▲

        Label(rodic,text="Ovládání",font=("Times",15),fg="steelblue").grid(row=0, column=2)
        Button(rodic, text="Zpátky",command=zpatky,bg="firebrick",fg="white",font=("Helvetica",8)).grid(row=0, column=3,sticky=E)
        Button(rodic, text="Jak   ?",command=napoveda,bg="steelblue",fg="white",font=("Helvetica",8)).grid(row=0, column=1,sticky=W)

        Label(rodic,text="  ").grid(row=1, column=1)

        Button(rodic,command=nahoru, text=y,bg="gainsboro").grid(row=2, column=2,sticky=N)

        Label(rodic, text=u"  ").grid(row=3, column=2,sticky=N)

        Button(rodic,command=doleva, text=u" <---",bg="gainsboro").grid(row=4, column=1,sticky=W)
        Button(rodic,command=stred, text=u"  ",bg="lightgrey").grid(row=4, column=2,sticky=N)
        Button(rodic,command=doprava, text=u"---> ",bg="gainsboro").grid(row=4, column=3,sticky=E)#alt 17,16

        Label(rodic, text=u"  ").grid(row=5, column=2,sticky=N)

        Button(rodic,command=dolu, text=x,bg="gainsboro").grid(row=6, column=2,sticky=N)


    def kresleninapoveda():
        clearscreen()
        master=Tk()
        def x():
            master.destroy()
            kresleni()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "Nápověda ke Kreslení",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "Spousta z nás si ráda kreslí. Na počítači je ale ")
        b = Label(master,text = "více metod kreslení než na papíře. Můžete kreslit")
        b2 = Label(master,text = "třeba šipkami,tak jako je to tady,v IMAGINE. Ale")
        a1 = Label(master,text= "i to je nutné se naučit. Proto jsou tady pro vás ")
        c = Label(master,text = "níže sepsané tipy, rady a ovládání tlačítek.")
        a2 = Label(master,text=" ")
        d = Button(master,bg="gainsboro",text = "--->")
        e = Label(master,text = " ")
        f = Label(master,text = "Šipky slouží k pohybu na papíře. Pohybujete se tak")
        g = Label(master,text = "jak vydíte, když zmáčknete tlačítko rovně,pojedete ")
        b1 = Label(master,text="rovně, když doprava, otočíte se o 45 stupňů doprava.")
        h = Label(master,text=  "Samozřejmě brzy vyjde nová verze se spoustou vylep-")
        ch= Label(master,text = "šení a s pohodlnějším ovládáním.(např. s přetáčním)")
        lop= Label(master,text = "Šipka dolů funguje jako zpátečka. Udělá krok zpět.")
        top= Label(master,text = "Na šipku musíte klikat, ne ji jen držet !")
        i = Label(master,text = " ")
        j = Button(master,bg="gainsboro",text = "   ")
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text="Tlačítko uprostřed ovládání slouží k nastavení ")
        k = Label(master,text = "Štětec NAHORU/DOLŮ. Zda je štětec nahoře či dole,")
        l = Label(master,text = "poznáte pomocí symbolů na štětci. Pokud je štětec")
        n = Label(master,text= "nahoře, má symbol oranžové šipky s výřezem na konci.")
        krop = Label(master,text= "Pokud dole (maluje) ,tak má symbol \"spláclého\"")
        o = Label(master,text= "trojuhelníku. Standartní nastavení je dole. A proč?")
        p= Label(master,text = "Tato funkce slouží k pohybování se po ploše aniž by")
        q= Label(master,text = "jste za sebou nechávali čáru.")
        mezera3=Label(master,text=" ")
        mezera4=Label(master,text=" ")


        zpatky = Button(master,text=" Zpátky ",bg="steelblue",fg="white",command=x)
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        okno.pack()

        nadpis.pack()
        a.pack()
        b.pack()
        b2.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        ch.pack()
        lop.pack()
        top.pack()
        i.pack()
        j.pack()
        mezera1.pack()
        mezera2.pack()
        k.pack()
        l.pack()
        n.pack()
        krop.pack()
        o.pack()
        p.pack()
        q.pack()
        mezera3.pack()
        zpatky.pack()
        mezera4.pack()
        copuz.pack()


    def hra():
        t = randrange(1,1000)
        x = "Myslím si číslo od 1 do 1000. Jaké to je?"
        f = True
        while f == True:

                h = numinput("Hra",x)
                if h<t :
                    x = h , "je moc malé!"

                if h>t:
                    x = h , "je moc velké!"

                if h == t :
                    f = False
                    master = Tk()
                    def pokracovat():
                        master.destroy()
                        hracicentrum()
                    def kal3():
                        master.destroy()
                        butt1()

                    d = Message(master, text= "Správně!",width= 50)
                    op = Button(master ,text="Pokračovat",command=pokracovat)
                    po = Button(master ,text="Zpátky",command=kal3,bg="steelblue",fg="white")
                    mezera1=Label(master,text=" ")
                    mezera2=Label(master,text=" ")
                    mezera3=Label(master,text=" ")
                    mezera4=Label(master,text=" ")

                    f = Canvas(master,width=200, height=5)
                    m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))

                    d.pack()
                    op.pack()
                    mezera1.pack()
                    po.pack()
                    mezera2.pack()
                    mezera3.pack()
                    mezera4.pack()
                    m.pack()
                    f.pack()

    def hra3_odcitani():
        master=Tk()
        def kd():
            master.destroy()
            hra3_odcitani()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def pododcitani():
            t=randint(1,100)
            g=randint(1,100)
            zadani = t,"-",g,"="
            h=numinput("Hra",zadani)
            if h==t-g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t-g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

        def otazkaPokracovani():
            a = Label(master, text="Správně!",font=("Helvetica", 10))
            b = Label(master, text="Špatně!",font=("Helvetica", 10))
            c = Button(master, text="Ok",command=kd)
            mezera1=Label(master,text=" ")
            mezera2=Label(master,text=" ")

            d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
            m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
            e = Canvas(master, width=200, height=5 )

        pododcitani()

    def hra2():
        master=Tk()
        def kd():
            master.destroy()
            hra2()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def podscitani():
            t=randint(1,100)
            g=randint(1,100)
            zadani = t,"+",g,"="
            h=numinput("Hra",zadani)
            if h==t+g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t+g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        podscitani()


    def hra4_deleni():
        master=Tk()
        def kd():
            master.destroy()
            hra4_deleni()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def poddeleni():
            t=randint(1,100)
            g=randint(1,10)
            zadani = t,"÷",g,"="
            h=numinput("Hra",zadani)
            if h==t//g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t//g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        poddeleni()


    def hra5_nasobeni():
        master=Tk()
        def kd():
            master.destroy()
            hra5_nasobeni()

        def ks():
            master.destroy()
            matematika()

        a = Label(master, text="Správně!",font=("Helvetica", 10))
        b = Label(master, text="Špatně!",font=("Helvetica", 10))
        c = Button(master, text="Ok",command=kd)
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        d = Button(master, text="Zpátky",bg = "steelblue",fg="white",command=ks)
        m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
        e = Canvas(master, width=200, height=5 )

        def podnasobeni():
            t=randint(1,10)
            g=randint(1,10)
            zadani = t,"·",g,"="
            h=numinput("Hra",zadani)
            if h==t*g:
                a.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()

            if h!=t*g:

                b.pack()
                mezera2.pack()
                c.pack()
                mezera1.pack()
                d.pack()
                e.pack()
                m.pack()
        podnasobeni()

    def napoveda():
        master = Tk()
        def x():
            master.destroy()
            butt1()
        okno = Canvas(master,width=350, height=5,bg="gold")
        nadpis = Label(master,text = "Nápověda",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "----------------------------------------------------------------------------")
        #a1 = Label(master,text= "----------------------------------------------------------------------------")
        #c = Label(master,anchor=W,text = "Co dělají jednotlivé kategorie?                                             ")
        #a2 = Label(master,text= "----------------------------------------------------------------------------")
        d = Label(master,anchor=W,text = "Kalkulačka                                                                  ")
        #e = Label(master,anchor=W,text = "Vypočítá vám zadaný příklad.                                                ")
        f = Label(master,anchor=W,text = "- Používá znaménka: ( +,-,*,÷ )                                              ")
        #g = Label(master,anchor=W,text = "> + pro sčítání_____________________________________________________________")
        #b1 = Label(master,anchor=W,text= "> - pro odčítání____________________________________________________________")
        #h = Label(master,anchor=W,text=  "> : pro dělení, zaokrouhluje pokud je výsledek v desetinných číslech, zvládá")
        #b2 = Label(master,anchor=W,text= "pouze celá čísla____________________________________________________________")
        #ch= Label(master,anchor=W,text = "> * pro násobení, zvládá pouze celá čísla                                   ")
        #i = Label(master,anchor=W,text = "Zadávání čísel:                                                             ")
        j = Label(master,anchor=W,text = "-Nejdříve napište pouze první číslo. Po každém řádku stiskněte Enter.       ")
        c1= Label(master,anchor=W,text = "-Následně (po stisknutí Enter) napište znak. Znaky jsou vypsány nad polem.  ")
        k = Label(master,anchor=W,text=  "-Napíšete druhé číslo. Potom stiskněte Enter a už vám vyjede výsledek :)    ")
        c2= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        l = Label(master,anchor=W,text = "Matematika                                                                  ")
        m = Label(master,text = "Funkce Matematika s vámi cvičí příklady na sčítání,odčítání,násobení    ")
        n = Label(master,anchor=W,text = "a dělení. Zvládá pouze celá čísla a zaokrouhluje. Je možné že vám vyjde")
        o = Label(master,text = "(s pravidly Funkce)neřešitelný příklad př(16÷3). Příklad pouze odklikněte a ")
        p = Label(master,anchor=W,text = "vyjede vám nový. Za případné komplikace se omlouváme.                       ")
        q = Label(master,text = "----------------------------------------------------------------------------")
        r = Label(master,anchor=W,text = "Hry                                                                         ")
        s = Label(master,text = "Funkce zatím obsahuje dvě hry. Druhá je vysvětlena výše(Matematika)        ")
        t = Label(master,text = "První je hra na hádání čísel. Čísla jsou vybírána pomocí funkce randint v   ")
        d1= Label(master,anchor=W,text = "modulu Random. Tedy náhodně. Vaším úkolem je číslo uhádnout na co    ")
        ok= Label(master,text = "nejmenší počet pokusů. Když číslo uhádnete, IMAGINE vám to napíše. Hra  ")
        d2= Label(master,anchor=W,text = "tím končí a vy se dostanete zpátky do menu.                                 ")
        d3= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        d4= Label(master,anchor=W,fg="steelblue",text = "O IMAGINE                                                                   ")
        d5= Label(master,anchor=W,text = "IMAGINE hodně čerpá z knihovny tkinter,většina grafických částí je vytvořena")
        d6= Label(master,anchor=W,text = "právě pomocí tkinteru. Prakticky všechna okna,texty a tlačítka. Dále IMAGINE")
        d7= Label(master,anchor=W,text = "používá modulu Random, tedy Náhody. Je použita ve hrách (na vygenerování")
        d8= Label(master,anchor=W,text = "hádaného čísla) a v Matematice(na generování náhodných čísel do příkladů)")
        d9= Label(master,anchor=W,text = "Jelikož Python nepoužívá příkaz go to(), je v kódu použito definvání(z 919")
        e1= Label(master,anchor=W,text = "jich pouze 7 není v žádné funkci). Tudíž je kód méně přehledný než jiné.Ale")
        e2= Label(master,anchor=W,text = "je to výtečný nápad-jenom kvůli tomu je IMAGINE schopná fungovat.           ")
        #e3= Label(master,anchor=W,text = "pouze přeskakuje z jedné funkce do jiné(což právě způsobuje nepřehlednost).")
        e4= Label(master,anchor=W,text = " ")
        e5= Label(master,anchor=W,text = "IMAGINE vznikla na nápad Pavla Koppa,a spousta nápadů (včetně Hry 1) pochází")
        #e6= Label(master,anchor=W,text = "Spousta nápadů(včetně Hry 1)")
        e7= Label(master,anchor=W,text = " od Programovacího Kroužku MakeItToday a od Instruktora Vítka. Těmto lidem ")
        e8= Label(master,anchor=W,text = "patří dík. Naprogramoval Tomáš Andrus.")
        e9= Label(master,anchor=W,text = "----------------------------------------------------------------------------")
        #e0= Label(master,anchor=W,text = " ")
        f1= Button(master,text="Zpátky",command=x,bg="steelblue",fg="white")

        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        nadpis.pack()

        a.pack()
        #a1.pack()
        #c.pack()
        #a2.pack()
        d.pack()
        #e.pack()
        f.pack()
        #g.pack()
        #b1.pack()
        #h.pack()
        #b2.pack()
        #ch.pack()
        #i.pack()
        j.pack()
        c1.pack()
        k.pack()
        c2.pack()
        l.pack()
        m.pack()
        n.pack()
        o.pack()
        p.pack()
        q.pack()
        r.pack()
        s.pack()
        t.pack()
        d1.pack()
        ok.pack()
        d2.pack()
        d3.pack()
        d4.pack()
        d5.pack()
        d6.pack()
        d7.pack()
        d8.pack()
        d9.pack()
        e1.pack()
        e2.pack()
        #e3.pack()
        e4.pack()
        e5.pack()
        #e6.pack()
        e7.pack()
        e8.pack()
        e9.pack()
        #e0.pack()
        f1.pack()


        copuz.pack()

        okno.pack()


    def hracicentrum():
        master=Tk()

        def a1():
            master.destroy()
            hra()
        def b1():
            master.destroy()
            clearscreen()
            pu()
            setpos(-100,0)  #pozice
            pd()
            hra2()
        def c1():
            master.destroy()
            butt1()

        a =Label(master,text="Jakou hru si chcete zahrát? ")
        b = Button(master, text="Hádání čísla",command= a1)
        c = Button(master, text="Sčítání,příklady",command=b1)
        x = Button(master, text="Zpátky",command=c1, bg="steelblue",fg="white")#dodgerblue/lehce svetlejsi
        d = Canvas(master, width=200, height=20)
        e_mezera = Label(master,text=" ")
        b_mezera = Label(master,text=" ")
        c_mezera = Label(master,text=" ")
        m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a.pack()

        b_mezera.pack()

        b.pack()

        e_mezera.pack()

        c.pack()

        c_mezera.pack()

        x.pack()
        d.pack()
        m.pack()
    def upgrade():
        master=Tk()
        def x():
            master.destroy()
            coming()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "A co s tím co už tady je?",fg="gold",font=("Helvetica",15))
        a = Label(master,text = "Nebojte,stále na tom pracujeme a vytváříme")
        b = Label(master,text = "nové verze již vydaných programů.")
        b2 = Label(master,text = "Na co se můžete těšit ?")
        a1 = Label(master,text=" ")
        c = Button(master,text = "Hry")
        a2 = Label(master,text=" ")
        d = Label(master,text = "Možná jste si všimli že naše hry zatím")
        e = Label(master,text = "nejsou nic extra. Je jich málo a jsou")
        f = Label(master,text = "víc matematické nežli zábavné.To vyřeší")
        g = Label(master,text = "následující verze IMAGINE! Bude větší ")
        b1 = Label(master,text="výběr her a budou lépe graficky zpracované.")
        h = Label(master,text=  "Přibyde také funkce na zmněnu jazyka. ")
        ch= Label(master,text = "K dispozici bude Angličtina a Čeština.")
        i = Label(master,text = "Na novou verzi IMAGINE(Hry, a Jazyky) se")
        j = Label(master,text = "můžete tešit 19.11.!Určitě se vám bude líbit.")
        mezera1=Label(master,text=" ")
        mezera2=Label(master,text=" ")

        zpatky = Button(master,text=" Zpátky ",bg="steelblue",fg="white",command=x)
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        okno.pack()

        nadpis.pack()
        a.pack()
        b.pack()
        b2.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        ch.pack()
        i.pack()
        j.pack()
        mezera1.pack()
        zpatky.pack()
        mezera2.pack()
        copuz.pack()

    def coming():
        master = Tk()
        def x():
            master.destroy()
            butt1()
        def up():
            master.destroy()
            upgrade()
        okno = Canvas(master,width=350, height=5)
        nadpis = Label(master,text = "Přijde vám to málo?",fg="steelblue",font=("Helvetica",15))
        a = Label(master,text = "Nám taky. A snažíme se na tom pracovat.")
        b = Label(master,text = "Již brzy vyjdou následující funkce:  ")
        a1 = Label(master,text=" ")
        c = Button(master,text = "Jazyky")
        a2 = Label(master,text=" ")
        d = Label(master,text = "Až doposud byla celá IMAGINE pouze v ")
        e = Label(master,text = "češtině. To se zmnění v následující")
        f = Label(master,text = "aktualizaci(19.11.). Celá IMAGINE bude")
        g = Label(master,text = "dostupná v angličtině. Vyjde 19-25.11.")
        b1 = Label(master,text=" ")
        h = Button(master,text = "Angličtina")
        b2 = Label(master,text=" ")
        ch= Label(master,text = "Funkce Angličtina vás naučí základy   ")
        i = Label(master,text = "Anglického Jazyka. Čísla,barvy,       ")
        j = Label(master,text = "zvířata atd. Funkce vyjde 3.12.       ")
        c1= Label(master,text = " ")
        k = Button(master,text="Chat")
        c2= Label(master,text = " ")
        l = Label(master,text = "Povídáte si rádi? A že nemáte s kým?  ")
        m = Label(master,text = "Nevadí! Od toho tu je iMagine,uživatesky")
        n = Label(master,text = "přívětivý program využívající strojového")
        o = Label(master,text = "učení TensorFlow.iMagine je milá,pozorná")
        p = Label(master,text = "a počítačově chytrá asistentka.       ")
        q = Label(master,text = "Svěřit se jí můžete opravdu se vším.  ")
        r = Label(master,text = "Říkat by to nikomu nemněla ☺. Datum   ")
        s = Label(master,text = "vydání je zatím bohužel neznámé. Očkává")
        t = Label(master,text = "se kolem lednu - únoru roku 2020.")
        d1= Label(master,text = " ")
        ok= Button(master,text= " Zpátky ",command=x,fg="white",bg ="steelblue")
        apk= Button(master,text= "Aktualizace",command=up,fg="white",bg ="gold")
        apk1m= Label(master,text = " ")

        #d2= Label(master,text = " ")
        copuz = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        nadpis.pack()

        a.pack()
        b.pack()
        a1.pack()
        c.pack()
        a2.pack()
        d.pack()
        e.pack()
        f.pack()
        g.pack()
        b1.pack()
        h.pack()
        b2.pack()
        ch.pack()
        i.pack()
        j.pack()
        c1.pack()
        k.pack()
        c2.pack()
        l.pack()
        m.pack()
        n.pack()
        o.pack()
        p.pack()
        q.pack()
        r.pack()
        s.pack()
        t.pack()
        apk1m.pack()
        apk.pack()
        d1.pack()
        ok.pack()
        #d2.pack()
        copuz.pack()

        okno.pack()

    def otazkaBack(x):
        master = Tk()
        def b1():
            master.destroy()
            if x == hracicentrum:
                hracicentrum()
            if x == kalkulacka:
                kalkulacka()
            if x == matematika:
                matematika()
        def c1():
            master.destroy()
            butt1()
        a =Label(master,text="Chcete pokračovat? ")
        b = Button(master, text="Pokračovat",command= b1)
        c = Button(master, text="Zpátky",command=c1, bg="steelblue",fg="white")#dodgerblue/lehce svetlejsi
        d = Canvas(master, width=200, height=80)
        e_mezera = Label(master,text=" ")
        b_mezera = Label(master,text=" ")
        m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a.pack()

        b_mezera.pack()

        b.pack()

        e_mezera.pack()

        c.pack()
        d.pack()
        m.pack()


    def butt1():
        master = Tk()

        def aj744():
            master.destroy()
            imaginecz()
        def a1():
            master.destroy()
            kalkulacka()

        def a2():
            master.destroy()
            matematika()

        def a3():
            master.destroy()
            hracicentrum()

        def a4():
            master.destroy()
            napoveda()
        def a5():
            master.destroy()
            clearscreen()
            shape("arrow")
            kresleni()
        def pripravujeme():
            master.destroy()
            coming()

        #x = Message(master,text= "Vyber:12" ,width=50) #snese pouye 8 znaku
        nadpis = Label(master,text="IMAGINE",font=("Helvetica", 30),fg="steelblue")
        h = Label(master, text=" „Think Different” ",font=("Helvetica", 8),fg="steelblue")
        ch= Label(master, text="Vyber si z těchto kategorií která tě zajímá. ")

        q = Label(master, text=" ")
        i = Label(master, text=" ")
        j = Label(master, text=" ")
        k = Label(master, text=" ")
        q = Label(master, text=" ")
        w = Label(master, text=" ")


        a = Button(master, text= "Kalkulačka",command=a1)
        b = Button(master, text= "Matematika",command=a2)
        c = Button(master, text= "Hry",command=a3)
        f = Button(master, text= "Kreslení",command=a5)
        chystase = Button(master, text= "Připravujeme",command=pripravujeme,bg="gold",fg="white")
        a1 = Label(master,text=" ")
        mezera1 = Label(master,text=" ")
        d = Button(master, text= "Nápověda",command=a4,bg="steelblue",fg="white")
        e = Canvas(master, width=400, height=20)

        nadpis.pack()
        h.pack()
        ch.pack()
        q.pack()

        a.pack()
        i.pack()

        b.pack()
        j.pack()

        c.pack()
        k.pack()
        f.pack()
        mezera1.pack()
        chystase.pack()
        a1.pack()

        d.pack()
        e.pack()
        l = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        l.pack(side=TOP)
        #q.pack()
        #w.pack()
        m = Label(master,text=" ")
        m.pack(side=LEFT)
        m = Label(master,text=" ")
        m.pack(side=LEFT)


        m = Button(master, text= "Čeština",command=aj744)
        m.pack(side=RIGHT)
        m = Button(master, text= "Angličtina",state=DISABLED,relief=SUNKEN)
        m.pack(side=RIGHT)


    def butt_uvodni():
        master = Tk()

        def aj744():
            master.destroy()
            imaginecz()
        def a1():
            master.destroy()
            kalkulacka()

        def a2():
            master.destroy()
            matematika()

        def a3():
            master.destroy()
            hracicentrum()

        def a4():
            master.destroy()
            napoveda()
        def a5():
            master.destroy()
            clearscreen()
            shape("arrow")
            kresleni()
        def pripravujeme():
            master.destroy()
            coming()
        nadpis = Label(master,text="IMAGINE",font=("Helvetica", 30),fg="steelblue")
        mezera1 = Label(master, text=" „Think Different” ",font=("Helvetica", 8),fg="steelblue")

        x = Label(master, text="Hello! My name is IMAGINE",fg= "black",font=("Helvetica", 10))    #fg/ barva pisma
        #x = Message(master,text= "Vyber:12" ,width=50) #snese pouye 8 znaku
        f1 = Label(master, text="I'm easy software for fun and learning.")
        g = Label(master, text=" And.. I'm not Jarvis ;). Have a fun !")
        h = Label(master, text=" ")
        ch= Label(master, text="Choose from categories: ")

        i = Label(master, text=" ")
        j = Label(master, text=" ")
        k = Label(master, text=" ")
        q = Label(master, text=" ")
        #w = Label(master, text=" ")

        #m = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))

        a = Button(master,padx=10, text= "Calculator",command=a1)
        b = Button(master,padx=23, text= "Math",command=a2)
        c = Button(master,padx=19, text= "Games",command=a3)
        d = Button(master,padx=25, text= "Help",command=a4,bg="steelblue",fg="white")
        f = Button(master,padx=14, text= "Painting",command=a5)

        chystase = Button(master,padx=1, text= "Coming soon",command=pripravujeme,bg="gold",fg="white")

        e = Canvas(master, width=400, height=5)

        #chystaseX = Label(master,text="Chystá se :")
        #chystase_1 = Button(master,text="Kreslení")
        #chystase_2 = Button(master,text="Angličtina")
        #chystase_3 = Button(master,text="Chat")
        a1= Label(master,text="")
        a2= Label(master,text="")
        a3= Label(master,text="")
        a4= Label(master,text="")
        ok1= Label(master,text="")
        ok2= Label(master,text="")


        nadpis.pack()
        mezera1.pack()
        x.pack()
        f1.pack()
        g.pack()
        h.pack()
        ch.pack()

        a.pack()
        i.pack()

        b.pack()
        j.pack()

        c.pack()
        k.pack()
        f.pack()
        ok1.pack()
        chystase.pack()
        a1.pack()
        #chystaseX.pack()
        #a1.pack()
        #chystase_1.pack()
        #chystase_1.config(state="disabled",relief="sunken")
        #a2.pack()
        #chystase_2.pack()
        #chystase_2.config(state="disabled",relief="sunken")
        #a3.pack()
        #chystase_3.pack()
        #chystase_3.config(state="disabled",relief="sunken")
        #a4.pack()
        d.pack()
        e.pack()

        q.pack()
        #w.pack()
        l = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
        l.pack(side=TOP)
        #q.pack()
        #w.pack()
        m = Label(master,text=" ")
        m.pack(side=LEFT)
        m = Label(master,text=" ")
        m.pack(side=LEFT)


        m = Button(master, text= "Czech",command=aj744)
        m.pack(side=RIGHT)
        m = Button(master, text= "English",state=DISABLED,relief=SUNKEN)
        m.pack(side=RIGHT)

    def imagine() :
        print("<<<Kalkulačka/Matematika/Hry/Nápověda>>>") #povídání,kreslení,angličtina,
        butt_uvodni()


    imagine()
    exitonclick()
    mainloop()

def heslo():
    master=Tk()
    master.title(" ")
    file = open("223heslo.txt","r")
    hesloxxx= file.read()

    file = open("uzivatelskejmeno.txt","r")
    uzjmeno= file.read()
    def okk():
        a1 = b.get()
        a2 = d.get()
        if a1 ==uzjmeno:
            if a2==hesloxxx:
                file.close()
                file.close()
                master.destroy()
                imaginecz()
            else:
                root=Tk()
                Label(root,text="Špatné\nHeslo!").pack()
                print("1Wrong Passworld")
        else:
            print("Wrong Name")
            root=Tk()
            Label(root,text="Špatné\nUživatelské jméno!").pack()
    a = Label(master,text="Uživatelské jméno:")
    a.pack()
    b = Entry(master)
    b.pack()
    c = Label(master,text="Heslo:")
    c.pack()
    d= Entry(master)
    d.pack()
    e = Label(master,text=" ")
    e.pack()
    f = Button(master,text="Ok",command=okk,bg="steelblue",fg="white")
    f.pack()
    #g = Label(master,text=" ")
    #g.pack()
    p=Canvas(master,height=10,width=200)#300,250,
    p.pack()
    m = Label(master,anchor=S, text="©2019 iMagine ",font=("Helvetica", 6))
    m.pack()
    #status = Label(master, text="", bd=1, relief=SUNKEN, anchor=W)
    #status.pack()
    #status["text"]="ajsdvv hsna ds e "



bgpic("logoimag.PNG")
file = open("yes-no.txt","r")
i=file.read()
if i=="yes":
    file.close()
    heslo()
if i=="no":
    file.close()
    def licence():
        pikol=Tk()
        pikol.title(" ")
        def regi():
            file= open("licence.txt","r")
            lic = b.get()
            i = file.read()
            if lic == i:
                file.close()
                pikol.destroy()
                def registrace():
                    master=Tk()
                    master.title(" ")
                    def registrace2():
                        master.destroy()
                        okno=Tk()
                        okno.title(" ")
                        def noveheslo22():
                            okno.destroy()
                            def ZMENAJMENA111():
                                okino.destroy()
                                okno=Tk()
                                okno.title(" ")
                                def novejm22():
                                    okno.destroy()
                                    def heslop():
                                        okino.destroy()
                                        file = open("yes-no.txt","w")
                                        file.write("yes")
                                        file.close()
                                        heslo()
                                    novejmeno44=textinput("NOVÉ JMÉNO","Zadejte nové Už. jméno:")
                                    file = open("uzivatelskejmeno.txt","w")
                                    file.write(novejmeno44)
                                    file.close()
                                    okino=Tk()
                                    okino.title(" ")
                                    a=Label(okino,text="Jméno bylo úspěšně\npřidáno !\nTak a teď to zkusíme.\nPřihlásíte se pomocí \njména a hesla které\njste teď zadali.")
                                    a.pack()
                                    b=Button(okino,text="Ok",fg="white",bg="steelblue",command=heslop)
                                    b.pack()
                                nadpis=Label(okno,text="NOVÉ JMÉNO",fg="steelblue",font=("Arial",15))
                                nadpis.pack()
                                a=Label(okno,text="Zadáte nové už. jméno a kliknete\n na Ok. Jméno je pouze\n na vás ale doporučujeme\n vybrat zapamatovatelné,\n alespoň o 5ti znacích.\n(Například tom_22)\nJméno použijete pro\npřihlášení.\n ")
                                a.pack()
                                b=Button(okno,text="Souhlasím",fg="white",bg="steelblue",command=novejm22)
                                b.pack()
                                c=Canvas(okno,height=10,width=200)
                                c.pack()
                                l = Label(okno, text="©2019 iMagine ",font=("Helvetica", 6))
                                l.pack()
                            noveheslo=textinput("NOVÉ HESLO","Zadejte nové heslo:")
                            file = open("223heslo.txt","w")
                            file.write(noveheslo)
                            file.close()
                            okino=Tk()
                            a=Label(okino,text="Heslo bylo úspěšně\npřidáno !")
                            a.pack()
                            b=Button(okino,text="Ok",fg="white",bg="steelblue",command=ZMENAJMENA111)
                            b.pack()
                        nadpis=Label(okno,text="NOVÉ HESLO",fg="steelblue",font=("Arial",15))
                        nadpis.pack()
                        a=Label(okno,text="Zadáte nové heslo a kliknete\n na Ok. Heslo je pouze\n na vás ale doporučujeme\n vybrat silné heslo \n alespoň o 5ti znacích.\n ")
                        a.pack()
                        b=Button(okno,text="Souhlasím",fg="white",bg="steelblue",command=noveheslo22)
                        b.pack()
                        c=Canvas(okno,height=10,width=200)
                        c.pack()
                        l = Label(okno, text="©2019 iMagine ",font=("Helvetica", 6))
                        l.pack()
                    nadpis=Label(master,text="IMAGINE",fg="steelblue",font=("Arial",20))
                    nadpis.pack()
                    a=Label(master,text="Ahoj, já jsem IMAGINE,uživatelsky přívětivý program\nna vzdělávání a zábavu. Nejspíše jste si mně před\nchvílí stáhli, a už chcete pokračovat. Tak jdeme na to.\nNejdříve si vyberete HESLO a poté UŽIVATELSKÉ JMÉNO.\n Oboje si zapamatujte!!! Budete je potřebovat. ")
                    a.pack()
                    c=Label(master,text=" ")
                    c.pack()
                    b=Button(master,text="Ok",fg="white",bg="steelblue",command=registrace2)
                    b.pack()
                    l = Label(master, text="©2019 iMagine ",font=("Helvetica", 6))
                    l.pack()
                    d=Canvas(master, width=400,height=5)#w1420 sirka monitoru a h540
                    d.pack()
                registrace()
            else:
                rik=Tk()
                rik.title(" ")
                a=Label(rik,text=" \nŠpatná licence. Zkuste\n zkontrolovat správnost\n znaků.\n ")
                a.pack()
        o=Label(pikol,text=" ")
        a=Label(pikol,text="Licenční klíč :")#font=(1))
        b=Entry(pikol,fg="black")
        c=Label(pikol,text=" ")
        d=Button(pikol,text="Ok",bg="steelblue",fg="white",command=regi)
        l = Label(pikol, text="©2019 iMagine ",font=("Helvetica", 6))
        p=Canvas(pikol,height=10,width=200)#300,250,
        o.pack()
        a.pack()
        b.pack()
        c.pack()
        d.pack()
        p.pack()
        l.pack()
    licence()
mainloop()
